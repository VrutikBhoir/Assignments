'use client';

import { useState } from 'react';

export default function ProductForm({ onSubmit }) {
  const [name, setName] = useState('');
  const [price, setPrice] = useState('');

  return (
    <form onSubmit={e => { e.preventDefault(); onSubmit({ name, price }); }} className="space-y-4">
      <input
        type="text"
        placeholder="Name"
        className="border p-2 w-full rounded"
        value={name}
        onChange={e => setName(e.target.value)}
        required
      />
      <input
        type="number"
        placeholder="Price"
        className="border p-2 w-full rounded"
        value={price}
        onChange={e => setPrice(e.target.value)}
        required
      />
      <button className="bg-blue-600 text-white px-4 py-2 rounded">
        Add Product
      </button>
    </form>
  );
}
