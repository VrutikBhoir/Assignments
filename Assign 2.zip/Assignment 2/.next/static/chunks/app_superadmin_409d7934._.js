(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/app/superadmin/data:53f4dc [app-client] (ecmascript) <text/javascript>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
/* __next_internal_action_entry_do_not_use__ [{"40138e4732e7b3c6df6fe512eee902e4a434abbdfe":"createUser"},"app/superadmin/actions.js",""] */ __turbopack_context__.s({
    "createUser": (()=>createUser)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
"use turbopack no side effects";
;
var createUser = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("40138e4732e7b3c6df6fe512eee902e4a434abbdfe", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "createUser"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vYWN0aW9ucy5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIndXNlIHNlcnZlcic7XHJcblxyXG5pbXBvcnQgeyBwcmlzbWEgfSBmcm9tIFwiQC9saWIvcHJpc21hXCI7XHJcblxyXG4vKipcclxuICogQ3JlYXRlIGEgbmV3IHVzZXIgZnJvbSBmb3JtRGF0YSAobmFtZSBhbmQgcGhvbmUpXHJcbiAqL1xyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY3JlYXRlVXNlcihmb3JtRGF0YSkge1xyXG4gIGNvbnN0IG5hbWUgPSBmb3JtRGF0YS5nZXQoJ25hbWUnKTtcclxuICBjb25zdCBwaG9uZSA9IGZvcm1EYXRhLmdldCgncGhvbmUnKTtcclxuXHJcbiAgaWYgKCFuYW1lIHx8ICFwaG9uZSkgcmV0dXJuO1xyXG5cclxuICBhd2FpdCBwcmlzbWEudXNlci5jcmVhdGUoe1xyXG4gICAgZGF0YTogeyBuYW1lLCBwaG9uZSB9LFxyXG4gIH0pO1xyXG59XHJcblxyXG4vKipcclxuICogR2V0IGFsbCB1c2VycyBvcmRlcmVkIGJ5IElEIGRlc2NlbmRpbmdcclxuICovXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRVc2VycygpIHtcclxuICBjb25zdCB1c2VycyA9IGF3YWl0IHByaXNtYS51c2VyLmZpbmRNYW55KHtcclxuICAgIG9yZGVyQnk6IHsgaWQ6ICdkZXNjJyB9LFxyXG4gIH0pO1xyXG4gIHJldHVybiB1c2VycztcclxufVxyXG5cclxuLyoqXHJcbiAqIFVwZGF0ZSBhbiBleGlzdGluZyB1c2VyIGJ5IElEIHVzaW5nIGZvcm1EYXRhIChuYW1lIGFuZCBwaG9uZSlcclxuICovXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiB1cGRhdGVVc2VyKGZvcm1EYXRhKSB7XHJcbiAgY29uc3QgaWQgPSBmb3JtRGF0YS5nZXQoJ2lkJyk7XHJcbiAgY29uc3QgbmFtZSA9IGZvcm1EYXRhLmdldCgnbmFtZScpO1xyXG4gIGNvbnN0IHBob25lID0gZm9ybURhdGEuZ2V0KCdwaG9uZScpO1xyXG5cclxuICBpZiAoIWlkIHx8ICFuYW1lIHx8ICFwaG9uZSkgcmV0dXJuO1xyXG5cclxuICBhd2FpdCBwcmlzbWEudXNlci51cGRhdGUoe1xyXG4gICAgd2hlcmU6IHsgaWQgfSxcclxuICAgIGRhdGE6IHsgbmFtZSwgcGhvbmUgfSxcclxuICB9KTtcclxufVxyXG5cclxuLyoqXHJcbiAqIERlbGV0ZSBhIHVzZXIgYnkgSURcclxuICovXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZWxldGVVc2VyKGZvcm1EYXRhKSB7XHJcbiAgY29uc3QgaWQgPSBmb3JtRGF0YS5nZXQoJ2lkJyk7XHJcblxyXG4gIGlmICghaWQpIHJldHVybjtcclxuXHJcbiAgYXdhaXQgcHJpc21hLnVzZXIuZGVsZXRlKHtcclxuICAgIHdoZXJlOiB7IGlkIH0sXHJcbiAgfSk7XHJcbn1cclxuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI2UkFPc0IifQ==
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/app/superadmin/data:6fb951 [app-client] (ecmascript) <text/javascript>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
/* __next_internal_action_entry_do_not_use__ [{"006af94274a1210811faf37da020bf0b06859c3603":"getUsers"},"app/superadmin/actions.js",""] */ __turbopack_context__.s({
    "getUsers": (()=>getUsers)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
"use turbopack no side effects";
;
var getUsers = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("006af94274a1210811faf37da020bf0b06859c3603", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "getUsers"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vYWN0aW9ucy5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIndXNlIHNlcnZlcic7XHJcblxyXG5pbXBvcnQgeyBwcmlzbWEgfSBmcm9tIFwiQC9saWIvcHJpc21hXCI7XHJcblxyXG4vKipcclxuICogQ3JlYXRlIGEgbmV3IHVzZXIgZnJvbSBmb3JtRGF0YSAobmFtZSBhbmQgcGhvbmUpXHJcbiAqL1xyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY3JlYXRlVXNlcihmb3JtRGF0YSkge1xyXG4gIGNvbnN0IG5hbWUgPSBmb3JtRGF0YS5nZXQoJ25hbWUnKTtcclxuICBjb25zdCBwaG9uZSA9IGZvcm1EYXRhLmdldCgncGhvbmUnKTtcclxuXHJcbiAgaWYgKCFuYW1lIHx8ICFwaG9uZSkgcmV0dXJuO1xyXG5cclxuICBhd2FpdCBwcmlzbWEudXNlci5jcmVhdGUoe1xyXG4gICAgZGF0YTogeyBuYW1lLCBwaG9uZSB9LFxyXG4gIH0pO1xyXG59XHJcblxyXG4vKipcclxuICogR2V0IGFsbCB1c2VycyBvcmRlcmVkIGJ5IElEIGRlc2NlbmRpbmdcclxuICovXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRVc2VycygpIHtcclxuICBjb25zdCB1c2VycyA9IGF3YWl0IHByaXNtYS51c2VyLmZpbmRNYW55KHtcclxuICAgIG9yZGVyQnk6IHsgaWQ6ICdkZXNjJyB9LFxyXG4gIH0pO1xyXG4gIHJldHVybiB1c2VycztcclxufVxyXG5cclxuLyoqXHJcbiAqIFVwZGF0ZSBhbiBleGlzdGluZyB1c2VyIGJ5IElEIHVzaW5nIGZvcm1EYXRhIChuYW1lIGFuZCBwaG9uZSlcclxuICovXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiB1cGRhdGVVc2VyKGZvcm1EYXRhKSB7XHJcbiAgY29uc3QgaWQgPSBmb3JtRGF0YS5nZXQoJ2lkJyk7XHJcbiAgY29uc3QgbmFtZSA9IGZvcm1EYXRhLmdldCgnbmFtZScpO1xyXG4gIGNvbnN0IHBob25lID0gZm9ybURhdGEuZ2V0KCdwaG9uZScpO1xyXG5cclxuICBpZiAoIWlkIHx8ICFuYW1lIHx8ICFwaG9uZSkgcmV0dXJuO1xyXG5cclxuICBhd2FpdCBwcmlzbWEudXNlci51cGRhdGUoe1xyXG4gICAgd2hlcmU6IHsgaWQgfSxcclxuICAgIGRhdGE6IHsgbmFtZSwgcGhvbmUgfSxcclxuICB9KTtcclxufVxyXG5cclxuLyoqXHJcbiAqIERlbGV0ZSBhIHVzZXIgYnkgSURcclxuICovXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZWxldGVVc2VyKGZvcm1EYXRhKSB7XHJcbiAgY29uc3QgaWQgPSBmb3JtRGF0YS5nZXQoJ2lkJyk7XHJcblxyXG4gIGlmICghaWQpIHJldHVybjtcclxuXHJcbiAgYXdhaXQgcHJpc21hLnVzZXIuZGVsZXRlKHtcclxuICAgIHdoZXJlOiB7IGlkIH0sXHJcbiAgfSk7XHJcbn1cclxuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiIyUkFxQnNCIn0=
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/app/superadmin/data:fe4c10 [app-client] (ecmascript) <text/javascript>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
/* __next_internal_action_entry_do_not_use__ [{"40aa205a01326dd75c8c93ca4b64dde38bae3db40d":"updateUser"},"app/superadmin/actions.js",""] */ __turbopack_context__.s({
    "updateUser": (()=>updateUser)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
"use turbopack no side effects";
;
var updateUser = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("40aa205a01326dd75c8c93ca4b64dde38bae3db40d", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "updateUser"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vYWN0aW9ucy5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIndXNlIHNlcnZlcic7XHJcblxyXG5pbXBvcnQgeyBwcmlzbWEgfSBmcm9tIFwiQC9saWIvcHJpc21hXCI7XHJcblxyXG4vKipcclxuICogQ3JlYXRlIGEgbmV3IHVzZXIgZnJvbSBmb3JtRGF0YSAobmFtZSBhbmQgcGhvbmUpXHJcbiAqL1xyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY3JlYXRlVXNlcihmb3JtRGF0YSkge1xyXG4gIGNvbnN0IG5hbWUgPSBmb3JtRGF0YS5nZXQoJ25hbWUnKTtcclxuICBjb25zdCBwaG9uZSA9IGZvcm1EYXRhLmdldCgncGhvbmUnKTtcclxuXHJcbiAgaWYgKCFuYW1lIHx8ICFwaG9uZSkgcmV0dXJuO1xyXG5cclxuICBhd2FpdCBwcmlzbWEudXNlci5jcmVhdGUoe1xyXG4gICAgZGF0YTogeyBuYW1lLCBwaG9uZSB9LFxyXG4gIH0pO1xyXG59XHJcblxyXG4vKipcclxuICogR2V0IGFsbCB1c2VycyBvcmRlcmVkIGJ5IElEIGRlc2NlbmRpbmdcclxuICovXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRVc2VycygpIHtcclxuICBjb25zdCB1c2VycyA9IGF3YWl0IHByaXNtYS51c2VyLmZpbmRNYW55KHtcclxuICAgIG9yZGVyQnk6IHsgaWQ6ICdkZXNjJyB9LFxyXG4gIH0pO1xyXG4gIHJldHVybiB1c2VycztcclxufVxyXG5cclxuLyoqXHJcbiAqIFVwZGF0ZSBhbiBleGlzdGluZyB1c2VyIGJ5IElEIHVzaW5nIGZvcm1EYXRhIChuYW1lIGFuZCBwaG9uZSlcclxuICovXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiB1cGRhdGVVc2VyKGZvcm1EYXRhKSB7XHJcbiAgY29uc3QgaWQgPSBmb3JtRGF0YS5nZXQoJ2lkJyk7XHJcbiAgY29uc3QgbmFtZSA9IGZvcm1EYXRhLmdldCgnbmFtZScpO1xyXG4gIGNvbnN0IHBob25lID0gZm9ybURhdGEuZ2V0KCdwaG9uZScpO1xyXG5cclxuICBpZiAoIWlkIHx8ICFuYW1lIHx8ICFwaG9uZSkgcmV0dXJuO1xyXG5cclxuICBhd2FpdCBwcmlzbWEudXNlci51cGRhdGUoe1xyXG4gICAgd2hlcmU6IHsgaWQgfSxcclxuICAgIGRhdGE6IHsgbmFtZSwgcGhvbmUgfSxcclxuICB9KTtcclxufVxyXG5cclxuLyoqXHJcbiAqIERlbGV0ZSBhIHVzZXIgYnkgSURcclxuICovXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZWxldGVVc2VyKGZvcm1EYXRhKSB7XHJcbiAgY29uc3QgaWQgPSBmb3JtRGF0YS5nZXQoJ2lkJyk7XHJcblxyXG4gIGlmICghaWQpIHJldHVybjtcclxuXHJcbiAgYXdhaXQgcHJpc21hLnVzZXIuZGVsZXRlKHtcclxuICAgIHdoZXJlOiB7IGlkIH0sXHJcbiAgfSk7XHJcbn1cclxuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI2UkErQnNCIn0=
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/app/superadmin/data:e56dd0 [app-client] (ecmascript) <text/javascript>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
/* __next_internal_action_entry_do_not_use__ [{"40ba68fc8ad291d7955a107f7b8007be4bb3f7130d":"deleteUser"},"app/superadmin/actions.js",""] */ __turbopack_context__.s({
    "deleteUser": (()=>deleteUser)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
"use turbopack no side effects";
;
var deleteUser = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("40ba68fc8ad291d7955a107f7b8007be4bb3f7130d", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "deleteUser"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vYWN0aW9ucy5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIndXNlIHNlcnZlcic7XHJcblxyXG5pbXBvcnQgeyBwcmlzbWEgfSBmcm9tIFwiQC9saWIvcHJpc21hXCI7XHJcblxyXG4vKipcclxuICogQ3JlYXRlIGEgbmV3IHVzZXIgZnJvbSBmb3JtRGF0YSAobmFtZSBhbmQgcGhvbmUpXHJcbiAqL1xyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY3JlYXRlVXNlcihmb3JtRGF0YSkge1xyXG4gIGNvbnN0IG5hbWUgPSBmb3JtRGF0YS5nZXQoJ25hbWUnKTtcclxuICBjb25zdCBwaG9uZSA9IGZvcm1EYXRhLmdldCgncGhvbmUnKTtcclxuXHJcbiAgaWYgKCFuYW1lIHx8ICFwaG9uZSkgcmV0dXJuO1xyXG5cclxuICBhd2FpdCBwcmlzbWEudXNlci5jcmVhdGUoe1xyXG4gICAgZGF0YTogeyBuYW1lLCBwaG9uZSB9LFxyXG4gIH0pO1xyXG59XHJcblxyXG4vKipcclxuICogR2V0IGFsbCB1c2VycyBvcmRlcmVkIGJ5IElEIGRlc2NlbmRpbmdcclxuICovXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRVc2VycygpIHtcclxuICBjb25zdCB1c2VycyA9IGF3YWl0IHByaXNtYS51c2VyLmZpbmRNYW55KHtcclxuICAgIG9yZGVyQnk6IHsgaWQ6ICdkZXNjJyB9LFxyXG4gIH0pO1xyXG4gIHJldHVybiB1c2VycztcclxufVxyXG5cclxuLyoqXHJcbiAqIFVwZGF0ZSBhbiBleGlzdGluZyB1c2VyIGJ5IElEIHVzaW5nIGZvcm1EYXRhIChuYW1lIGFuZCBwaG9uZSlcclxuICovXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiB1cGRhdGVVc2VyKGZvcm1EYXRhKSB7XHJcbiAgY29uc3QgaWQgPSBmb3JtRGF0YS5nZXQoJ2lkJyk7XHJcbiAgY29uc3QgbmFtZSA9IGZvcm1EYXRhLmdldCgnbmFtZScpO1xyXG4gIGNvbnN0IHBob25lID0gZm9ybURhdGEuZ2V0KCdwaG9uZScpO1xyXG5cclxuICBpZiAoIWlkIHx8ICFuYW1lIHx8ICFwaG9uZSkgcmV0dXJuO1xyXG5cclxuICBhd2FpdCBwcmlzbWEudXNlci51cGRhdGUoe1xyXG4gICAgd2hlcmU6IHsgaWQgfSxcclxuICAgIGRhdGE6IHsgbmFtZSwgcGhvbmUgfSxcclxuICB9KTtcclxufVxyXG5cclxuLyoqXHJcbiAqIERlbGV0ZSBhIHVzZXIgYnkgSURcclxuICovXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZWxldGVVc2VyKGZvcm1EYXRhKSB7XHJcbiAgY29uc3QgaWQgPSBmb3JtRGF0YS5nZXQoJ2lkJyk7XHJcblxyXG4gIGlmICghaWQpIHJldHVybjtcclxuXHJcbiAgYXdhaXQgcHJpc21hLnVzZXIuZGVsZXRlKHtcclxuICAgIHdoZXJlOiB7IGlkIH0sXHJcbiAgfSk7XHJcbn1cclxuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI2UkErQ3NCIn0=
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/app/superadmin/page.jsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>UserPage)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hook$2d$form$2f$dist$2f$index$2e$esm$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-hook-form/dist/index.esm.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$superadmin$2f$data$3a$53f4dc__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/superadmin/data:53f4dc [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$superadmin$2f$data$3a$6fb951__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/superadmin/data:6fb951 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$superadmin$2f$data$3a$fe4c10__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/superadmin/data:fe4c10 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$superadmin$2f$data$3a$e56dd0__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/superadmin/data:e56dd0 [app-client] (ecmascript) <text/javascript>");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
function UserPage() {
    _s();
    const { register, handleSubmit, reset, setValue } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hook$2d$form$2f$dist$2f$index$2e$esm$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useForm"])();
    const [users, setUsers] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [editingId, setEditingId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    async function loadUsers() {
        const allUsers = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$superadmin$2f$data$3a$6fb951__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["getUsers"])();
        setUsers(allUsers);
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "UserPage.useEffect": ()=>{
            loadUsers();
        }
    }["UserPage.useEffect"], []);
    const onSubmit = async (data)=>{
        const formData = new FormData();
        formData.append('name', data.name);
        formData.append('phone', data.phone);
        if (editingId) {
            formData.append('id', editingId);
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$superadmin$2f$data$3a$fe4c10__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["updateUser"])(formData);
            setEditingId(null);
        } else {
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$superadmin$2f$data$3a$53f4dc__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["createUser"])(formData);
        }
        await loadUsers();
        reset();
    };
    const handleEdit = (user)=>{
        setEditingId(user.id);
        setValue('name', user.name);
        setValue('phone', user.phone);
    };
    const handleDelete = async (id)=>{
        const formData = new FormData();
        formData.append('id', id);
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$superadmin$2f$data$3a$e56dd0__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["deleteUser"])(formData);
        await loadUsers();
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "p-6 max-w-md mx-auto",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                className: "text-xl font-bold mb-4",
                children: editingId ? 'Edit User' : 'Add User'
            }, void 0, false, {
                fileName: "[project]/app/superadmin/page.jsx",
                lineNumber: 53,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                onSubmit: handleSubmit(onSubmit),
                className: "space-y-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        ...register('name'),
                        placeholder: "Name",
                        className: "w-full p-2 border rounded"
                    }, void 0, false, {
                        fileName: "[project]/app/superadmin/page.jsx",
                        lineNumber: 56,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        ...register('phone'),
                        placeholder: "Phone Number",
                        className: "w-full p-2 border rounded"
                    }, void 0, false, {
                        fileName: "[project]/app/superadmin/page.jsx",
                        lineNumber: 57,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "submit",
                        className: "bg-blue-600 text-white px-4 py-2 rounded",
                        children: editingId ? 'Update' : 'Submit'
                    }, void 0, false, {
                        fileName: "[project]/app/superadmin/page.jsx",
                        lineNumber: 58,
                        columnNumber: 9
                    }, this),
                    editingId && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: ()=>{
                            reset();
                            setEditingId(null);
                        },
                        className: "ml-2 text-gray-500 underline",
                        children: "Cancel"
                    }, void 0, false, {
                        fileName: "[project]/app/superadmin/page.jsx",
                        lineNumber: 62,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/superadmin/page.jsx",
                lineNumber: 55,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-6",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "text-lg font-semibold",
                        children: "Submitted Users:"
                    }, void 0, false, {
                        fileName: "[project]/app/superadmin/page.jsx",
                        lineNumber: 76,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                        className: "mt-2 space-y-2",
                        children: users.map((user)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                className: "p-2 border rounded flex justify-between items-center",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: [
                                            "👤 ",
                                            user.name,
                                            " – 📞 ",
                                            user.phone
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/superadmin/page.jsx",
                                        lineNumber: 80,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "space-x-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: ()=>handleEdit(user),
                                                className: "text-blue-500 hover:underline",
                                                children: "Edit"
                                            }, void 0, false, {
                                                fileName: "[project]/app/superadmin/page.jsx",
                                                lineNumber: 82,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: ()=>handleDelete(user.id),
                                                className: "text-red-500 hover:underline",
                                                children: "Delete"
                                            }, void 0, false, {
                                                fileName: "[project]/app/superadmin/page.jsx",
                                                lineNumber: 88,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/superadmin/page.jsx",
                                        lineNumber: 81,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, user.id, true, {
                                fileName: "[project]/app/superadmin/page.jsx",
                                lineNumber: 79,
                                columnNumber: 13
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/app/superadmin/page.jsx",
                        lineNumber: 77,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/superadmin/page.jsx",
                lineNumber: 75,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/superadmin/page.jsx",
        lineNumber: 52,
        columnNumber: 5
    }, this);
}
_s(UserPage, "MnMZ0WxzcvD8crYnZd23npq6MsA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hook$2d$form$2f$dist$2f$index$2e$esm$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useForm"]
    ];
});
_c = UserPage;
var _c;
__turbopack_context__.k.register(_c, "UserPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=app_superadmin_409d7934._.js.map