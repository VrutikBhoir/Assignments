(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_1cc04d97._.js",
  "static/chunks/app_user_page_jsx_1283ad69._.js"
],
    source: "dynamic"
});
