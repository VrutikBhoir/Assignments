(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__501b62d3._.css",
  "static/chunks/node_modules_@clerk_nextjs_dist_esm_app-router_179308f5._.js",
  "static/chunks/node_modules_15f411e7._.js"
],
    source: "dynamic"
});
