
import React from 'react'

function home() {
  return (
    <>
    <h1></h1>
    </>
  )
}

export default home