import { prisma } from '@/lib/prisma';

export default async function HomePage() {
  const products = await prisma.product.findMany();

  const formatPrice = (price) =>
    new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
    }).format(price);

  return (
    <main className="p-8">
      <h1 className="text-4xl font-extrabold mb-10 text-center">🛍️ Our Products</h1>

      {products.length === 0 ? (
        <p className="text-center text-gray-500">No products available.</p>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {products.map((product) => (
            <div
              key={product.id}
              className="bg-white border rounded-lg shadow-md hover:shadow-lg transition p-4 flex flex-col"
            >
              {/* Placeholder image */}
              <div className="h-40 bg-gray-100 rounded mb-4 flex items-center justify-center text-gray-400 text-sm">
                Image
              </div>

              <h2 className="text-lg font-semibold mb-1">{product.name}</h2>
              <p className="text-gray-600 mb-2">{formatPrice(product.price)}</p>

              {/* Optional button or link */}
              <button className="mt-auto bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition">
                View Details
              </button>
            </div>
          ))}
        </div>
      )}
    </main>
  );
}
